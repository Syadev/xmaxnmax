# hopper

**index.js**
Auto register dengan SMSHUB / SMS RU menggunakan email random

**auto_trick.js**
Auto register dengan SMSHUB / SMS RU menggunakan gmail dotrick

**manual.js**
Manual register dengan request email dan nomor (fisik / non fisik)

**getReff.js**
Mendapatkan kode referral akun yang sudah dibuat / belum dibuat

**cekSaldo.js**
Cek cash carrot akun yang sudah dibuat
